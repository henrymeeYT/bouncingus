
extends CharacterBody2D

# Player settings
const SPEED = 600.0
const JUMP_VELOCITY = -600.0
const WALL_BOUNCE_SPEED = 10000.0
const BOUNCE_TIME = 1.0
const BOUNCE_COOLDOWN = 0.5

# Death settings
const DEATH_Y = 1500.0
const RESPAWN_DELAY = 0.5

# Sign settings
const SIGN_TEXT = "Welcome to my game!"

# Animation
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

var bounce_timer = 0.0
var bounce_cooldown_timer = 0.0

# Respawn and checkpoints
var respawn_position: Vector2
var current_checkpoint = "Start"

var is_dead = false

# Sign
var nearby_sign: Area2D = null
var message_label: Label
var sign_open = false

func _ready() -> void:
	respawn_position = global_position

	# Create sign text
	message_label = Label.new()
	message_label.position = Vector2(-100, -100)
	message_label.add_theme_font_size_override("font_size", 24)
	message_label.z_index = 100
	message_label.hide()
	add_child(message_label)

func _physics_process(delta: float) -> void:

	if is_dead:
		return

	# Death detection
	if global_position.y > DEATH_Y:
		die()
		return

	# Gravity
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Cooldown
	if bounce_cooldown_timer > 0:
		bounce_cooldown_timer -= delta

	# Jump
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Movement
	if bounce_timer > 0:
		bounce_timer -= delta
	else:
		var direction := Input.get_axis("ui_left", "ui_right")

		if direction:
			velocity.x = direction * SPEED
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)

	# Animations
	if not is_on_floor():
		play_animation("jump")
	elif velocity.x > 0:
		play_animation("walk right")
	elif velocity.x < 0:
		play_animation("walk left")
	else:
		play_animation("default")

	# Move player
	var old_velocity_x = velocity.x
	move_and_slide()

	# Wall bounce
	if bounce_cooldown_timer <= 0:
		for i in range(get_slide_collision_count()):
			var collision = get_slide_collision(i)
			var normal = collision.get_normal()

			if abs(normal.x) > 0.9 and abs(old_velocity_x) > 0.1:
				velocity.x = normal.x * WALL_BOUNCE_SPEED
				bounce_timer = BOUNCE_TIME
				bounce_cooldown_timer = BOUNCE_COOLDOWN
				break

	# Read sign with DOWN
	if nearby_sign != null and Input.is_action_just_pressed("ui_down"):
		sign_open = not sign_open

		if sign_open:
			message_label.text = SIGN_TEXT
			message_label.show()
		else:
			message_label.hide()


# Checkpoint activation
func activate_checkpoint(checkpoint_name: String, checkpoint_position: Vector2) -> void:
	respawn_position = checkpoint_position
	current_checkpoint = checkpoint_name
	print("Checkpoint activated: ", current_checkpoint)


# Death and respawn
func die() -> void:
	is_dead = true
	velocity = Vector2.ZERO
	message_label.hide()
	sign_open = false

	await get_tree().create_timer(RESPAWN_DELAY).timeout

	global_position = respawn_position
	velocity = Vector2.ZERO
	bounce_timer = 0.0
	bounce_cooldown_timer = 0.0
	is_dead = false

	play_animation("default")
	print("Respawned at: ", current_checkpoint)


func play_animation(animation_name: String) -> void:
	if anim.animation != animation_name:
		anim.play(animation_name)


# Sign detection
func _on_sign_body_entered(body: Node2D) -> void:
	if body == self:
		nearby_sign = body

func _on_sign_body_exited(body: Node2D) -> void:
	if body == self:
		nearby_sign = null
		message_label.hide()
		sign_open = false
