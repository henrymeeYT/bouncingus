
extends CharacterBody2D

@export var speed = 300.0
@export var jump_force = -400.0
@export var gravity = 980.0

func _physics_process(delta):
	if not is_on_floor():
		velocity.y += gravity * delta

	# TEMPORARY TEST: jump without checking the floor
	if Input.is_action_just_pressed("ui_up"):
		velocity.y = jump_force
		print("JUMP BUTTON WORKS!")

	var direction = Input.get_axis("ui_left", "ui_right")
	velocity.x = direction * speed

	move_and_slide()
