
extends Area2D

@export var checkpoint_name = "C1"

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		body.activate_checkpoint(checkpoint_name, global_position)
